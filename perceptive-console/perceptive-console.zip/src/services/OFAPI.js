import axios from 'axios';

let OFAPI_URL = "http://localhost:3030";

let OFAPI = {
    OpenFace : {
        getFrameData(base64_string){
            return axios.get(OFAPI_URL, {
                    params : {
                        image : base64_string
                    },
                    headers : {
                        'Content-Type' : 'text/html'
                    }
            });
        }
    }
}

export default OFAPI;