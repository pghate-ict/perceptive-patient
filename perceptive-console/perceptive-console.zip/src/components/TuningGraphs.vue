<template>
    
</template>

<script>
export default {
    data : function(){
        return {

        }
    },
    methods : {

    }
}
</script>

<style>

</style>
