<template>
    
</template>

<script>
    export default {
        name : 'ScoreDial',
        data(){
            return{
                
            }
        }
    }
</script>
<style scoped>

</style>
