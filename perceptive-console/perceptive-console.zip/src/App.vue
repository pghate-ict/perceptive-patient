<template>
  <perceptive-patient/>
</template>

<script>
import PerceptivePatient from './components/PerceptivePatient';


export default {
  components : {
    PerceptivePatient
  },
  name: "App",
  methods : {
    
  }
};
</script>

<style>
</style>
